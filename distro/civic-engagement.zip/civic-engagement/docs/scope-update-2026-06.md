# Scope Update – June 2026

## Purpose

This document records scope clarifications and agreements reached after the first client review of the prototype.

This document supplements the original proposal and requirements documents.

Where conflicts exist between the original requirements and the review discussions, this document takes precedence.

---

# Current Development Status

Core modules are operational:

* Representations
* Consultations
* Consultation Responses
* Consultation Custom Fields
* Events
* Event Registrations
* Event Custom Fields
* Schedules
* Schedule Notes
* Contact Management
* Activity Tracking
* Frontend Widgets

Current focus:

* Client review refinements
* UI improvements
* Testing and stabilisation

---

# Accepted For Current Release

## Representations

### Subject Label

Replace:

Title

with:

Subject

### Mandatory Fields

Make mandatory:

* Name
* Email

### WhatsApp Support

Copy phone number to WhatsApp field automatically.

User may edit the value.

### Image Upload

Support:

* Single image upload
* Optional field
* Representation only

No image galleries.

### Administrative Status Tracking

Add:

* Status
* Internal Comment

Suggested statuses:

* New
* Seen
* In Progress
* Completed
* Closed

No workflow automation.

No audit trail.

No history tracking.

Status applies to the individual Representation.

---

## Consultations

### Button Label

Replace:

Respond to this Consultation

with:

Have Your Say

### Public Responses

Disable public response listings by default.

Moderation functionality remains available.

### Response Count Offset

Add configurable field:

starting_response_count

Displayed count:

starting_response_count + actual_responses_received

---

## Consultation Responses

### Administrative Status Tracking

Add:

* Status
* Internal Comment

Suggested statuses:

* New
* Seen
* In Progress
* Completed
* Closed

No workflow automation.

No audit trail.

No history tracking.

Status applies to the individual Consultation Response.

---

## Events

### Volunteer Area

No code change required.

The client was referring to an Event Custom Field in sample data rather than a core Event module field.

The field may be removed from the relevant event configuration where appropriate.

### Participant Limits

Not included.

Current version allows unrestricted registrations.

### Civic Media Support

Consultations, Events, and Schedules support multiple WordPress Media Library images with captions. The first image is the primary public image; later images appear as selectable thumbnails.

---

## Schedules

### Recent Update

Add editable field:

recent_update

Visible in public schedule listing.

### Status Date

Rename:

End Date

to:

Status Date

### Priority

Add simple priority field.

Used for schedule sorting only.

No workflow functionality.

### Review Date

Deferred.

Not included in current release.

---

## Contacts

### Communication Consent

Add consent option to public forms.

Store consent against contact record.

## Consent Management

Consent is treated as cumulative and may only be promoted from No to Yes in V1.

When an existing contact submits a new form:

- A positive selection promotes the matching consent flag only when it is currently No.
- Blank or unselected options do not revoke or otherwise overwrite previously granted consent.
- The consent timestamp changes only when a flag is promoted.

Formal opt-out and unsubscribe functionality is outside the scope of the current release and will be handled by a future communication module.

### Consent Filtering

Allow filtering contacts by consent status.

### Contact Export

Allow export of consented contacts.

### Contact Matching

Continue using email-based contact matching.

---

## Homepage / UI

### Homepage Hero

Support hero image or video section.

### Theme Refinement

Apply client branding and colour preferences.

---

## Spam Prevention

Implement CAPTCHA or equivalent spam-prevention mechanism.

---

# Deferred Until Core Enhancements Are Complete

## Schedule Comments

Public schedule comments require separate review.

Not included in current release.

If implemented in the future, status tracking requirements will be reviewed separately.

---

## URL Routing

Canonical Slug Routing V1 is implemented using module-prefixed URLs:

* `/consultation/{slug}`
* `/event/{slug}`
* `/schedule/{slug}`

Slug uniqueness is enforced only within each module. Public routing resolves only publicly visible records, and legacy numeric ID URLs redirect permanently to the canonical route. Root-level routing and a global slug registry remain outside the current scope.

### Short URL Routing V1

Short URLs are available for consultations, events, and schedules using `/go/{short_code}` by default. They redirect permanently to the relevant canonical slug URL. Short codes are optional, use lowercase letters, numbers, and hyphens, and are globally unique across the three modules. Prefix configuration, URL analytics, click tracking, QR codes, and bulk management remain deferred.

---

# Not Included In Current Release

The following items are not currently planned:

* Email campaign management
* SMS campaign management
* Unsubscribe workflow management
* Advanced workflow automation
* Audit trails
* Process history tracking
* Event capacity management

---

# Open Decisions

The following items require client confirmation before implementation:

* Media strategy for consultations/events/schedules
* Public schedule comments

---

# Development Order

1. Administrative status tracking for Representations
2. Administrative status tracking for Consultation Responses
3. Response Count Offset
4. Recent Update
5. Priority
6. Consent Management
7. Representation Image Upload
8. UI Refinement
9. Client Review
10. Routing follow-up / Media Decisions
